$(function(){
	$('.yxnewItem img').hover(function(){
		$('#intoxppd').show();
	},function(){
		$('#intoxppd').hide();
	});
	$('.xiaoYi img').hover(function(){
		$('#intoxyss').show();
	},function(){
		$('#intoxyss').hide();
	});
	$('.yxFind img').hover(function(){
		$('#intoyxfx').show();
	},function(){
		$('#intoyxfx').hide();
	});
});
